﻿# SalesSight 360 — Official Submission Package

## 🔗 Live Application Links
- **Public Cloud Live Link**: [https://chatty-rice-act.loca.lt](https://chatty-rice-act.loca.lt)  
  *(Tunnel Password / Endpoint IP if prompted by localtunnel: `157.66.147.152`)*
- **Local Browser Link**: [http://localhost:8501](http://localhost:8501)
- **Local Network Link**: [http://192.168.0.107:8501](http://192.168.0.107:8501)

---

## 📊 Executive Presentation
- **PowerPoint File**: `SalesSight_360_Executive_Presentation.pptx` (10 widescreen 16:9 slides with executive KPI cards, dimensional star-schema architecture, 22-point validation audit, and embedded dashboard screenshots).

---

## 📦 Submission Files Included in Zip
1. **Interactive BI Dashboard**: `dashboard/app.py` (5 Streamlit pages with Plotly visualizations).
2. **Executive Presentation**: `SalesSight_360_Executive_Presentation.pptx`.
3. **Dimensional Data Warehouse**: `data/processed/sales_sight_360.db` (SQLite 3 with 11 star-schema tables).
4. **Source & Cleaned Data**: `data/raw/*.csv` and `data/processed/*.csv`.
5. **Python Engineering & Analytics Engine**:
   - `python/run_all.py` (Master pipeline orchestrator)
   - `python/generate_sample_data.py` (Synthetic enterprise dataset generator)
   - `python/etl_pipeline.py` (Idempotent ETL & database builder)
   - `python/validate_data.py` (22-point data quality & integrity assertion engine)
   - `python/kpi_calculations.py` (Centralized business KPI engine)
   - `python/forecasting.py` (Holt-Winters / ARIMA 90-day predictive revenue modeling)
   - `python/generate_reports.py` (Executive analytical report generator)
   - `python/capture_screenshots.py` (Playwright automated screenshot capture)
6. **Automated Test Suite**: `tests/run_tests.py` (22 / 22 unit & integration tests passed).
7. **Production SQL**: `sql/schema.sql`, `sql/kpi_queries.sql`, `sql/funnel_analysis.sql`, `sql/forecast_analysis.sql`, `sql/data_quality_checks.sql`.
8. **Reports & Exports**: `reports/*.csv` and `reports/executive_revenue_report.md`.
9. **Dashboard Screenshots**: 6 high-resolution 1600x1000 screenshots in `screenshots/`.
10. **Documentation**: `README.md`, `requirements.txt`, and `docs/architecture.md`.

---

## ⚡ Quick Start Instructions
```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the full data pipeline, validation checks & tests
python python/run_all.py

# 3. Launch the Streamlit dashboard
streamlit run dashboard/app.py
```
